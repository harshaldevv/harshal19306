from tabula import *
from os import *

print("Extracting the tables from the pdfs...")
print("Saving the tables in CSV file...")
convert_into_by_batch("PDFs", output_format = "csv", pages = "all")
print("Successfully Completed!")
