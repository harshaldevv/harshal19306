I'm sharing a couple of PDFs here.
Each of these is a 1 pager containing 1 or more tables.
We'd like to see if you can come up with some python 3.6 code that, given path to local pdf file location capture ONLY the tables into and store as CSV back to the same location (1 csv per table)
You are free to use any open source libraries that you can get your hands on.
Let us know how it goes. We encourage you to report any partial progress that you might be making.